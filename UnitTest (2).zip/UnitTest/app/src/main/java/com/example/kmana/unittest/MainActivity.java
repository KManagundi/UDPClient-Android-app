package com.example.kmana.unittest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class MainActivity extends AppCompatActivity {


    EditText editTextAddress, editTextPort;
    String udpOutputData;
    boolean StatusSendUdp;
    String ServerAddress;
    Integer ServerPort;
    //-----UDP send thread
    private void sendData(String add, Integer prt) {


        if(udpOutputData==null) return;

        try{

            // get server name
            //InetAddress serverAddr = InetAddress.getByName("192.168.0.104");
            InetAddress serverAddr = InetAddress.getByName(add);
            Log.d("UDP", "C: Connecting...");

            // create new UDP socket
            DatagramSocket socket = new DatagramSocket();

            // prepare data to be sent
            byte[] buf = udpOutputData.getBytes();

            // create a UDP packet with data and its destination ip & port
            DatagramPacket packet = new DatagramPacket(buf, buf.length,serverAddr,prt);
            Log.d("UDP", "C: Sending: '" + new String(buf) + "'");

            // send the UDP packet
            socket.send(packet);
            Log.d("UDP", "PORT:"+ socket.getPort());
            socket.close();

            Log.d("UDP", "C: Sent.");
            Log.d("UDP", "C: Done.");
            Log.d("UDP", "C: Done.");


        } catch (Exception e) {
            e.printStackTrace();
            Log.e("UDP", "C: Error", e);
        }


             /*       StatusSendUdp = false;
                }


            }*/

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextAddress = (EditText) findViewById(R.id.address);
        editTextPort = (EditText) findViewById(R.id.port);
        Button button = findViewById(R.id.Start_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickStart();
            }
        });
    }



    public void sendUdp(String udpMsg, final String address, Integer port) {
        udpOutputData = udpMsg;
        StatusSendUdp = true;
        ServerAddress=address;
        ServerPort=port;
        Executors.newFixedThreadPool(4).execute(new Runnable() {
            @Override
            public void run() {
                sendData(ServerAddress,ServerPort);
            }
        });
    }

    public void onClickStart(){

        sendUdp("START", editTextAddress.getText().toString(), Integer.parseInt(editTextPort.getText().toString()));
        Toast.makeText(getApplicationContext(),"RECORDING STARTED", Toast.LENGTH_SHORT).show();


    }





    public void Stop_OnClick(View view) {

        sendUdp("STOP",editTextAddress.getText().toString(),Integer.parseInt(editTextPort.getText().toString()));
        Toast.makeText(getApplicationContext(),"RECORDING STOPPED", Toast.LENGTH_SHORT).show();

    }


    public void Close_OnClick(View view) {
        sendUdp("CLOSE",editTextAddress.getText().toString(),Integer.parseInt(editTextPort.getText().toString()));
        Toast.makeText(getApplicationContext(),"CLOSING UDP SERVER", Toast.LENGTH_SHORT).show();
    }
}

